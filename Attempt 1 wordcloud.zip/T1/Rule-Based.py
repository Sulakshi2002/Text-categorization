import os
import re
import json
import glob
import textwrap
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pathlib import Path
from matplotlib import font_manager

# -------------------------------------------------
# CONFIGURATION
# -------------------------------------------------
TRANSCRIPT_FILE = "trans/20260101-084910_0773169775-all_transcript.txt"
KEYWORDS_FOLDER = "keywords"
OUTPUT_IMAGE = "customer_insight.png"
FONT_PATH = "NotoSansSinhala-Regular.ttf"          # your font file

# -------------------------------------------------
# Register Sinhala font
# -------------------------------------------------
def register_sinhala_font(font_path):
    if not os.path.exists(font_path):
        raise FileNotFoundError(f"Font file not found: {font_path}")
    font_manager.fontManager.addfont(font_path)
    return font_manager.FontProperties(fname=font_path)

# -------------------------------------------------
# Load data
# -------------------------------------------------
def load_transcript(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read().strip()

def load_categories(folder_path):
    categories = {}
    for file_path in sorted(glob.glob(os.path.join(folder_path, "*.json"))):
        cat_name = Path(file_path).stem.replace("_", " ").title()
        with open(file_path, "r", encoding="utf-8") as f:
            categories[cat_name] = json.load(f)
    return categories

# -------------------------------------------------
# Split sentences
# -------------------------------------------------
def split_sentences(text):
    sentences = re.split(r'(?<=[.?!\n])\s+', text)
    return [s.strip() for s in sentences if len(s.strip()) > 12]

# -------------------------------------------------
# RULE-BASED PATTERNS (Most Important Part)
# -------------------------------------------------
STRONG_PATTERNS = [
    # Billing + Disconnection
    {
        "name": "Billing Disconnection",
        "keywords": ["බිල්", "බිල්පත්", "ඩිස්කනෙක්ට්", "විසන්ධි", "disconnect"],
        "bonus": 8.0
    },
    # Payment made but not updated
    {
        "name": "Payment Not Updated",
        "keywords": ["පේමන්ට්", "ගෙව්වා", "ගෙවලා", "අප්ඩේට්", "update", "නැහැ", "නැද්ද"],
        "bonus": 7.5
    },
    # Outstanding / Due amount
    {
        "name": "Outstanding Amount",
        "keywords": ["ගෙවන්න තියෙනවා", "ගෙවන්න ඕනේ", "outstanding", "අවුට්ස්ටෑන්ඩින්", "හිඟ", "ඇරියස්", "due"],
        "bonus": 6.5
    },
    # Technical fault (wire/cable)
    {
        "name": "Technical Fault",
        "keywords": ["වයර්", "කේබල්", "කැඩිලා", "බ්‍රේක්", "breakdown", "හදන්න", "නඩත්තු"],
        "bonus": 7.0
    },
    # Connection not active after payment
    {
        "name": "Not Activated",
        "keywords": ["ඇක්ටිව්", "active", "activate", "වෙලා නැහැ", "වෙලා නෑ", "තාම"],
        "bonus": 6.0
    },
    # Complaint related
    {
        "name": "Complaint",
        "keywords": ["කම්ප්ලේන්", "complaint", "පැමිණිල්ල", "යොමු"],
        "bonus": 4.0
    }
]

def apply_rules(sentence):
    sentence_lower = sentence.lower()
    bonus = 0.0
    matched_rules = []

    for rule in STRONG_PATTERNS:
        hits = sum(1 for kw in rule["keywords"] if kw.lower() in sentence_lower)
        if hits >= 2:                       # at least 2 keywords from the rule
            bonus += rule["bonus"]
            matched_rules.append(rule["name"])
        elif hits == 1:
            bonus += rule["bonus"] * 0.4    # partial match

    return bonus, matched_rules

# -------------------------------------------------
# Score sentence (Keywords + Rules)
# -------------------------------------------------
def score_sentence(sentence, categories):
    sentence_lower = sentence.lower()
    keyword_score = 0.0
    category_scores = {cat: 0.0 for cat in categories}

    # 1. Weighted keyword score
    for cat_name, keywords in categories.items():
        for keyword, weight in keywords.items():
            matches = len(re.findall(re.escape(str(keyword).lower()), sentence_lower))
            score = matches * float(weight)
            keyword_score += score
            category_scores[cat_name] += score

    # 2. Rule-based bonus
    rule_bonus, matched_rules = apply_rules(sentence)

    total_score = keyword_score + rule_bonus
    return total_score, category_scores, matched_rules

# -------------------------------------------------
# Extract insight
# -------------------------------------------------
def extract_insight(text, categories, top_n=3):
    sentences = split_sentences(text)
    scored = []

    for sent in sentences:
        total, cat_scores, rules = score_sentence(sent, categories)
        if total > 1.0:          # ignore very low scores
            scored.append({
                "sentence": sent,
                "score": total,
                "categories": cat_scores,
                "rules": rules
            })

    scored = sorted(scored, key=lambda x: x["score"], reverse=True)
    top_sentences = scored[:top_n]

    # Dominant category
    overall = {cat: 0.0 for cat in categories}
    for item in scored:
        for cat, sc in item["categories"].items():
            overall[cat] += sc
    dominant_category = max(overall, key=overall.get) if overall else "Unknown"

    return top_sentences, dominant_category

# -------------------------------------------------
# Create image
# -------------------------------------------------
def create_insight_image(top_sentences, dominant_category, call_name, output_path, font_prop):
    fig, ax = plt.subplots(figsize=(12, 8.5))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis("off")

    # Background
    ax.add_patch(patches.FancyBboxPatch(
        (0.3, 0.3), 9.4, 9.4,
        boxstyle="round,pad=0.05,rounding_size=0.3",
        facecolor="#FFF8F0", edgecolor="#E67E22", linewidth=3
    ))

    # Title
    ax.text(5, 9.35, "පාරිභෝගිකයාගේ ප්‍රධාන කරුණ", 
            fontsize=22, ha="center", va="center", fontweight="bold",
            color="#D35400", fontproperties=font_prop)

    # Call name
    ax.text(5, 8.75, f"Call: {call_name}", 
            fontsize=12, ha="center", color="#7F8C8D", fontproperties=font_prop)

    # Category badge
    ax.add_patch(patches.FancyBboxPatch(
        (2.0, 7.75), 6.0, 0.7,
        boxstyle="round,pad=0.1,rounding_size=0.2",
        facecolor="#E67E22", edgecolor="none"
    ))
    ax.text(5, 8.1, f"Main Category: {dominant_category}", 
            fontsize=13, ha="center", va="center", color="white", fontweight="bold",
            fontproperties=font_prop)

    # Sentences
    y = 6.95
    for i, item in enumerate(top_sentences):
        wrapped = textwrap.fill(item["sentence"], width=50)
        ax.text(0.6, y, f"{i+1}.", fontsize=14, fontweight="bold",
                color="#E67E22", fontproperties=font_prop)
        ax.text(1.2, y, wrapped, fontsize=13, va="top", color="#2C3E50",
                linespacing=1.4, fontproperties=font_prop)
        y -= (wrapped.count("\n") + 1) * 0.62 + 0.38

    # Footer
    ax.text(5, 0.65, "Rule-based + Keyword extraction", 
            fontsize=10, ha="center", color="#95A5A6", style="italic",
            fontproperties=font_prop)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close()
    print(f"Image saved → {output_path}")

# -------------------------------------------------
# MAIN
# -------------------------------------------------
def main():
    print("Registering font...")
    font_prop = register_sinhala_font(FONT_PATH)

    print("Loading transcription...")
    text = load_transcript(TRANSCRIPT_FILE)
    call_name = Path(TRANSCRIPT_FILE).stem

    print("Loading keywords...")
    categories = load_categories(KEYWORDS_FOLDER)

    print("Extracting insight (Rule-Based)...")
    top_sentences, dominant_category = extract_insight(text, categories, top_n=3)

    if not top_sentences:
        print("No strong sentences found.")
        return

    print("\n===== Extracted Insight =====")
    print(f"Dominant Category : {dominant_category}")
    print("\nTop sentences:")
    for i, item in enumerate(top_sentences, 1):
        rules = ", ".join(item["rules"]) if item["rules"] else "Keyword only"
        print(f"{i}. [{item['score']:.1f}] ({rules})")
        print(f"   {item['sentence'][:100]}...\n")

    print("Creating image...")
    create_insight_image(top_sentences, dominant_category, call_name, OUTPUT_IMAGE, font_prop)
    print("Done!")

if __name__ == "__main__":
    main()
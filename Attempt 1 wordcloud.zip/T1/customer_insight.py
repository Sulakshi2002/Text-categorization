import os
import re
import json
import glob
import textwrap
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pathlib import Path
from matplotlib import font_manager

# -------------------------------------------------
# CONFIGURATION
# -------------------------------------------------
TRANSCRIPT_FILE = "trans/20260101-084910_0773169775-all_transcript.txt"          # change if needed
KEYWORDS_FOLDER = "keywords"
OUTPUT_IMAGE = "customer_insight.png"

# Path to your font file (you already have this file)
FONT_PATH = "NotoSansSinhala-Regular.ttf"             # same folder as the script

# -------------------------------------------------
# Register the Sinhala font
# -------------------------------------------------
def register_sinhala_font(font_path):
    if not os.path.exists(font_path):
        raise FileNotFoundError(f"Font file not found: {font_path}")
    
    font_manager.fontManager.addfont(font_path)
    font_prop = font_manager.FontProperties(fname=font_path)
    print(f"Font registered: {font_prop.get_name()}")
    return font_prop

# -------------------------------------------------
# 1. Load transcription
# -------------------------------------------------
def load_transcript(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        return f.read().strip()

# -------------------------------------------------
# 2. Load keyword categories
# -------------------------------------------------
def load_categories(folder_path):
    categories = {}
    json_files = sorted(glob.glob(os.path.join(folder_path, "*.json")))
    if not json_files:
        raise FileNotFoundError(f"No JSON files found in {folder_path}")
    
    for file_path in json_files:
        cat_name = Path(file_path).stem.replace("_", " ").title()
        with open(file_path, "r", encoding="utf-8") as f:
            keywords = json.load(f)
        categories[cat_name] = keywords
    return categories

# -------------------------------------------------
# 3. Split sentences
# -------------------------------------------------
def split_sentences(text):
    sentences = re.split(r'(?<=[.?!\n])\s+', text)
    return [s.strip() for s in sentences if len(s.strip()) > 15]

# -------------------------------------------------
# 4. Score sentence
# -------------------------------------------------
def score_sentence(sentence, categories):
    sentence_lower = sentence.lower()
    total_score = 0.0
    category_scores = {cat: 0.0 for cat in categories}

    for cat_name, keywords in categories.items():
        for keyword, weight in keywords.items():
            matches = len(re.findall(re.escape(str(keyword).lower()), sentence_lower))
            score = matches * float(weight)
            total_score += score
            category_scores[cat_name] += score

    return total_score, category_scores

# -------------------------------------------------
# 5. Extract insight
# -------------------------------------------------
def extract_insight(text, categories, top_n=3):
    sentences = split_sentences(text)
    scored = []

    for sent in sentences:
        total, cat_scores = score_sentence(sent, categories)
        if total > 0:
            scored.append({
                "sentence": sent,
                "score": total,
                "categories": cat_scores
            })

    scored = sorted(scored, key=lambda x: x["score"], reverse=True)
    top_sentences = scored[:top_n]

    overall_cat_scores = {cat: 0.0 for cat in categories}
    for item in scored:
        for cat, sc in item["categories"].items():
            overall_cat_scores[cat] += sc

    dominant_category = max(overall_cat_scores, key=overall_cat_scores.get) if overall_cat_scores else "Unknown"
    dominant_score = overall_cat_scores.get(dominant_category, 0)

    return top_sentences, dominant_category, dominant_score

# -------------------------------------------------
# 6. Create the visual image (with proper font)
# -------------------------------------------------
def create_insight_image(top_sentences, dominant_category, call_name, output_path, font_prop):
    fig, ax = plt.subplots(figsize=(12, 8))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 10)
    ax.axis("off")

    # Background
    ax.add_patch(patches.FancyBboxPatch(
        (0.3, 0.3), 9.4, 9.4,
        boxstyle="round,pad=0.05,rounding_size=0.3",
        facecolor="#FFF8F0", edgecolor="#E67E22", linewidth=3
    ))

    # Title
    ax.text(5, 9.3, "පාරිභෝගිකයාගේ ප්‍රධාන කරුණ", 
            fontsize=22, ha="center", va="center", fontweight="bold",
            color="#D35400", fontproperties=font_prop)

    # Call name
    ax.text(5, 8.7, f"Call: {call_name}", 
            fontsize=12, ha="center", va="center", color="#7F8C8D",
            fontproperties=font_prop)

    # Dominant Category Badge
    ax.add_patch(patches.FancyBboxPatch(
        (2.2, 7.7), 5.6, 0.7,
        boxstyle="round,pad=0.1,rounding_size=0.2",
        facecolor="#E67E22", edgecolor="none"
    ))
    ax.text(5, 8.05, f"Main Category: {dominant_category}", 
            fontsize=13, ha="center", va="center", color="white", fontweight="bold",
            fontproperties=font_prop)

    # Top Sentences
    y_start = 6.9
    for i, item in enumerate(top_sentences):
        sentence = item["sentence"]
        wrapped = textwrap.fill(sentence, width=52)
        
        ax.text(0.7, y_start, f"{i+1}.", fontsize=14, fontweight="bold",
                color="#E67E22", fontproperties=font_prop)
        ax.text(1.3, y_start, wrapped, fontsize=13, va="top", color="#2C3E50",
                linespacing=1.45, fontproperties=font_prop)
        
        y_start -= (wrapped.count("\n") + 1) * 0.65 + 0.35

    # Footer
    ax.text(5, 0.7, "Auto-extracted important sentences from transcription", 
            fontsize=10, ha="center", color="#95A5A6", style="italic",
            fontproperties=font_prop)

    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close()
    print(f"Image saved: {output_path}")

# -------------------------------------------------
# MAIN
# -------------------------------------------------
def main():
    print("Registering Sinhala font...")
    font_prop = register_sinhala_font(FONT_PATH)

    print("Loading transcription...")
    text = load_transcript(TRANSCRIPT_FILE)
    call_name = Path(TRANSCRIPT_FILE).stem

    print("Loading keywords...")
    categories = load_categories(KEYWORDS_FOLDER)

    print("Extracting customer insight...")
    top_sentences, dominant_category, dominant_score = extract_insight(text, categories, top_n=3)

    if not top_sentences:
        print("No important sentences found.")
        return

    print("\n===== Extracted Insight =====")
    print(f"Dominant Category : {dominant_category}")
    print(f"Score             : {dominant_score:.1f}")
    print("\nTop sentences:")
    for i, item in enumerate(top_sentences, 1):
        print(f"{i}. [{item['score']:.1f}] {item['sentence'][:90]}...")

    print("\nCreating image...")
    create_insight_image(top_sentences, dominant_category, call_name, OUTPUT_IMAGE, font_prop)
    print("Done!")

if __name__ == "__main__":
    main()
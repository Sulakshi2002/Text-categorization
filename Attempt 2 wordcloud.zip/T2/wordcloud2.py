import os
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from wordcloud import WordCloud

# ---------------------------------------------------------
# 1. CATEGORY COLOR MAPPER
# ---------------------------------------------------------
class SinhalaCategoryColorFunc:
    def __init__(self, word_to_category_map):
        self.word_map = word_to_category_map
        # 4 distinct colors for the 4 main categories
        self.category_colors = {
            'bill': '#1f77b4',     # Blue (Bill Inquiries)
            'fault': '#d62728',    # Red (Faults)
            'product': '#2ca02c',  # Green (Product & New GB)
            'number': '#9467bd'    # Purple (Telephone Number Request)
        }

    def __call__(self, word, font_size, position, orientation, font_path=None, random_state=None):
        cat = self.word_map.get(word, 'bill')
        return self.category_colors.get(cat, '#333333')

# ---------------------------------------------------------
# 2. SINHALA PHRASES & FREQUENCIES
# ---------------------------------------------------------
frequencies = {
    # 1. Bill Inquiries (Blue)
    'ලයින් එක ඇක්ටිව් වෙලා නැහැ': 50,
    'අවුට්ස්ටෑන්ඩින් බිල කීයද': 45,
    'ගෙවපු මුදල අප්ඩේට් වෙලා නෑ': 40,
    'බිල්පත චෙක් කරගන්න': 35,
    'ගෙවිය යුතු අවසාන දිනය': 30,

    # 2. Faults (Red)
    'රවුටරයේ රතු පාට ලයිට් පත්තු වෙනවා': 48,
    'බල්බ් පත්තු වෙන්නේ නැහැ': 42,
    'ඕෆ් කරලා ඕන් කරලා බලන්න': 38,
    'රවුටර් සෙටින්ග්ස් හදන්න': 32,
    'වයර් කැඩිලා තියෙන්නේ': 36,

    # 3. Product & New GB (Green)
    'ලොකේෂන් එක වෙනස් කරගන්න': 44,
    'අමතර GB ඇඩ් කරගන්න': 46,
    'අලුත් පැකේජ් එකකට අප්ග්‍රේඩ්': 34,
    'ඩේටා ප්‍රමාණය චෙක් කරන්න': 30,

    # 4. Telephone Number Request (Purple)
    'අලුත් කනෙක්ෂන් නම්බර් එක': 38,
    'දුරකථන අංකය වෙනස් කරන්න': 32,
    'අංකය තහවුරු කරගන්න': 28
}

# ---------------------------------------------------------
# 3. CATEGORY MAPPING FOR SINHALA PHRASES
# ---------------------------------------------------------
word_to_category = {
    # Bill Inquiries
    'ලයින් එක ඇක්ටිව් වෙලා නැහැ': 'bill',
    'අවුට්ස්ටෑන්ඩින් බිල කීයද': 'bill',
    'ගෙවපු මුදල අප්ඩේට් වෙලා නෑ': 'bill',
    'බිල්පත චෙක් කරගන්න': 'bill',
    'ගෙවිය යුතු අවසාන දිනය': 'bill',
    
    # Faults
    'රවුටරයේ රතු පාට ලයිට් පත්තු වෙනවා': 'fault',
    'බල්බ් පත්තු වෙන්නේ නැහැ': 'fault',
    'ඕෆ් කරලා ඕන් කරලා බලන්න': 'fault',
    'රවුටර් සෙටින්ග්ස් හදන්න': 'fault',
    'වයර් කැඩිලා තියෙන්නේ': 'fault',
    
    # Product & GB
    'ලොකේෂන් එක වෙනස් කරගන්න': 'product',
    'අමතර GB ඇඩ් කරගන්න': 'product',
    'අලුත් පැකේජ් එකකට අප්ග්‍රේඩ්': 'product',
    'ඩේටා ප්‍රමාණය චෙක් කරන්න': 'product',
    
    # Number Request
    'අලුත් කනෙක්ෂන් නම්බර් එක': 'number',
    'දුරකථන අංකය වෙනස් කරන්න': 'number',
    'අංකය තහවුරු කරගන්න': 'number'
}

# ---------------------------------------------------------
# 4. FONT SETUP & WORD CLOUD GENERATION
# ---------------------------------------------------------
font_path = 'Iskoola Pota Regular.ttf'  

if not os.path.exists(font_path):
    # Fallback search for Nirmala UI or Iskoola Pota in Windows fonts folder
    if os.path.exists('C:/Windows/Fonts/iskpota.ttf'):
        font_path = 'C:/Windows/Fonts/iskpota.ttf'
    else:
        font_path = 'C:/Windows/Fonts/Nirmala.ttf'

# Load the Sinhala font for Matplotlib UI elements (like Title)
sinhala_font = FontProperties(fname=font_path)

color_func = SinhalaCategoryColorFunc(word_to_category)

wc = WordCloud(
    font_path=font_path,
    width=1400, 
    height=900, 
    background_color='white', 
    max_words=100,
    random_state=42,
    collocations=False  # Prevents splitting multi-word phrases
).generate_from_frequencies(frequencies)

# Recolour with category mapping
wc.recolor(color_func=color_func)

# ---------------------------------------------------------
# 5. DISPLAY & SAVE
# ---------------------------------------------------------
plt.figure(figsize=(14, 9))
plt.imshow(wc, interpolation='bilinear')
plt.axis('off')

# Format the title text cleanly
title_text = "සිංහල සංවාද විශ්ලේෂණ Word Cloud\n(නිල්: බිල්පත් ගැටලු | රතු: තාක්ෂණික දෝෂ | කොළ: නිෂ්පාදන/GB | දම්: දුරකථන අංක ඉල්ලීම්)"

# Explicitly pass fontproperties so Matplotlib uses the Sinhala font for the title
plt.title(
    title_text, 
    fontproperties=sinhala_font,
    fontsize=14, 
    fontweight='bold', 
    pad=20
)

plt.tight_layout()
plt.savefig('sinhala_transcript_wordcloud.png', dpi=300)
plt.show()
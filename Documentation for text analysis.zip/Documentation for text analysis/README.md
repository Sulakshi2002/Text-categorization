# Sinhala Telecom Classifier

A simple offline Sinhala telecom inquiry classifier that uses fuzzy keyword matching to categorize user text.

## Project Structure

- `classification.py` — main classifier script.
- `README.md` — documentation.
- `categories/` — folder containing JSON keyword dictionaries for each category.
  - `bill_inquiries.json`
  - `product_and_new_service.json`
  - `fault_and_technical.json`
  - `telephone_number_request_or_other.json`

## Prerequisites

- Python 3.8 or newer.
- No external dependencies required.

## Setup

1. Open a terminal in `d:\final`.
2. (Optional) Create and activate a virtual environment:

```bash
python -m venv venv
venv\Scripts\activate
```

3. Run the classifier:

```bash
python t4.py
```

## How It Works

The classifier follows these steps:

1. Load category keyword dictionaries from separate JSON files.
2. Preprocess input text.
3. Tokenize Sinhala and alphanumeric text.
4. Compare tokens with keywords using fuzzy similarity.
5. Calculate weighted scores per category.
6. Pick the category with the highest score.
7. Print the result and evidence.

## Category Files

Each category uses a separate JSON file inside `categories/`.
This makes it easier to update keywords without changing the Python code.

Example category loader in `t4.py`:

```python
CATEGORY_FILES = {
    "Bill_Inquiries": "bill_inquiries.json",
    "Fault_and_Technical": "fault_and_technical.json",
    "Product_And_New_Service": "product_and_new_service.json",
    "Telephone_Number_Request_Or_Other": "telephone_number_request_or_other.json"
}

with open(file_path, "r", encoding="utf-8") as file:
    patterns[category] = json.load(file)
```

## Step-by-Step Guide

### Step 01: Development Environment

Use Python 3.8 or newer.
Keep `t4.py` and `categories/` in the same folder.

### Step 02: Install Required Libraries

No external libraries are required. The script uses only standard library modules: `json`, `os`, and `re`.

### Step 03: Create the Category Matrix

Define the categories the classifier can predict.

```python
self.categories = [
    "Bill_Inquiries",
    "Fault_and_Technical",
    "Product_And_New_Service",
    "Telephone_Number_Request_Or_Other"
]
```

### Step 04: Create Domain Keyword Dictionaries

Put each category's keyword dictionary in its own JSON file.
Each JSON file should map Sinhala keywords to weights.

Example from `bill_inquiries.json`:

```json
{
  "බිල්": 1.0,
  "බිල්පත්": 1.0,
  "පේමන්ට්": 1.0,
  "රුපියල්": 0.9
}
```

### Step 05: Implement Levenshtein Distance

Use Levenshtein distance to measure how many character edits separate two words.

```python
def _levenshtein_distance(self, s1, s2):
    if len(s1) < len(s2):
        return self._levenshtein_distance(s2, s1)
    if len(s2) == 0:
        return len(s1)

    previous_row = range(len(s2) + 1)
    for i, c1 in enumerate(s1):
        current_row = [i + 1]
        for j, c2 in enumerate(s2):
            insertions = previous_row[j + 1] + 1
            deletions = current_row[j] + 1
            substitutions = previous_row[j] + (c1 != c2)
            current_row.append(min(insertions, deletions, substitutions))
        previous_row = current_row

    return previous_row[-1]
```

### Step 06: Calculate Similarity Score

Convert the edit distance into a score between 0 and 1.

```python
def _calculate_similarity(self, word1, word2):
    max_len = max(len(word1), len(word2))
    if max_len == 0:
        return 0.0
    dist = self._levenshtein_distance(word1, word2)
    return (max_len - dist) / max_len
```

### Step 07: Preprocess the Input Text

Normalize input by lowercasing and trimming whitespace.

```python
normalized_text = str(raw_noisy_text).lower().strip()
```

### Step 08: Tokenize Sinhala Text

Split input into Sinhala and alphanumeric tokens.

```python
tokens = re.findall(r'[a-zA-Z0-9]+|[\u0D80-\u0DFF]+', normalized_text)
```

### Step 09: Initialize Category Score Matrix

Prepare scores and logs.

```python
category_scores = {cat: 0.0 for cat in self.categories}
evidence_logs = []
seen_tokens_in_category = set()
```

### Step 10: Perform Keyword Matching

Compare each token to category keywords.

```python
for token in tokens:
    if len(token) < 2:
        continue

    for cat in self.categories:
        for kw, intent_weight in self.domain_patterns[cat].items():
            sim = self._calculate_similarity(token, kw)
            if sim >= match_threshold:
                ...
                break
```

### Step 11: Calculate Weighted Scores

Score exact and fuzzy matches.

```python
base_weight = 5.0 if sim == 1.0 else (3.0 * sim)
calculated_score = base_weight * intent_weight
if match_key in seen_tokens_in_category:
    calculated_score *= 0.25
else:
    seen_tokens_in_category.add(match_key)
category_scores[cat] += calculated_score
evidence_logs.append(
    f"  - Token '{token}' matched with '{kw}' in {cat} "
    f"(Sim: {sim:.2f}, Final Weight: {calculated_score:.2f})"
)
```

### Step 12: Select the Maximum Likelihood Category

Choose the highest-scoring category.

```python
max_score = max(category_scores.values())
if max_score == 0:
    predicted_category = "UNKNOWN_DIRECT_INQUIRY"
else:
    predicted_category = [cat for cat, score in category_scores.items() if score == max_score][0].upper()
```

### Step 13: Display Prediction Results

Return the result and print it.

```python
return {
    "predicted_category": predicted_category,
    "raw_scoring_matrix": {c: round(v, 2) for c, v in category_scores.items()},
    "evidence": evidence_logs
}
```

Terminal display:

```python
result = classifier.predict(user_input)
print(f"\nPrediction Outcome   : {result['predicted_category']}")
print(f"Scoring Weights Matrix: {result['raw_scoring_matrix']}")
print("Matched Evidence Logs :")
if not result['evidence']:
    print("  No meaningful token alignments mapped above 0.80 threshold.")
else:
    for log in result['evidence'][:15]:
        print(log)
    if len(result['evidence']) > 15:
        print(f"  ... and {len(result['evidence']) - 15} more logs matched.")
```

## Notes

- Keep the `categories/` folder next to `t4.py`.
- To change keywords, edit the JSON files instead of `t4.py`.
- This classifier is built for offline Sinhala telecom inquiry text classification.
